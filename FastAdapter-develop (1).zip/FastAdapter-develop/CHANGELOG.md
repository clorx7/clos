You can find a detailed change log in the [release section](https://github.com/mikepenz/FastAdapter/releases)
