FastAdapter contributors (sorted alphabetically)
============================================

* **[Fabian Terhorst](https://github.com/FabianTerhorst)**

  * EndlessScroll-Listener (EndlessScroll Sample)
  * Improvements to the `SimpleDragCallback`
  * Add additional tests
  * Add `FastAdapterDialog`
  * Add additional default `Items`
  
* **[MFlisar](https://github.com/MFlisar)**

  * Improvements to the Expandable / SubItems implementation

* **[Mattias Isegran Bergander](https://github.com/mattiasbe)**

  * "Leave-Behind"-Pattern (SwipeList Sample)

* **[Rainer Lang](https://github.com/Rainer-Lang)**

  * CheckBoxSample
  * RadioButtonSample

* **[rubengees](https://github.com/rubengees)**

  * SortSample with comparator

* **[Shubham Chaudhary](https://github.com/shubhamchaudhary)**
  
  * Basic Unit-Tests

* **[Alireza](https://github.com/meNESS)**
 
  * EndlessRecyclerOnTopScrollListener

* **[jasonsparc](https://github.com/jasonsparc)**

  * Added `EndlessScrollHelper`