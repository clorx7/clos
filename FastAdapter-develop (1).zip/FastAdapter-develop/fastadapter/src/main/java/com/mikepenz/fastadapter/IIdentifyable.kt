package com.mikepenz.fastadapter

/**
 * Created by mikepenz on 03.02.15.
 */
interface IIdentifyable {
    var identifier: Long
}