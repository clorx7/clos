package com.mikepenz.fastadapter.drag

/**
 * Created by mikepenz on 30.12.15.
 */
interface IDraggable {
    /** @return true if draggable */
    val isDraggable: Boolean
}
