package com.mikepenz.fastadapter.app.model

import com.mikepenz.iconics.typeface.IIcon

/**
 * Created by mikepenz on 18.01.16.
 */
open class IconModel(var icon: IIcon)
